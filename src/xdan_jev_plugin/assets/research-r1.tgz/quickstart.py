from pathlib import Path
from xdan_jev_runtime import SemanticJevModel
model = SemanticJevModel.from_pretrained(Path(__file__).resolve().parent, device="cuda")
print(model.infer({"messages": [{"role": "user", "content": "What is 2 + 2? Choose exactly one of [3, 4]. Reply with only the selected option."}]}, mode="auto"))
