"""Single-backbone research runtime, exported with relative vendored dependencies."""

import hashlib
import json
import time
from pathlib import Path

from .release_contract import (
    SCHEMA_V1,
    SCHEMA_V2,
    ROUTE_DEPTHS,
    EFFORT_DEPTHS,
    head_path,
    resolve_route_controls,
    BASE_REPO,
    BASE_REVISION,
    CLASSES,
    candidate_tokens,
    choose_route,
    clean_input,
    literal_candidates,
    metadata,
    model_messages,
)


def file_hash(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


REQUIRED_RELEASE_FILES = {
    "config.json",
    "tokenizer.json",
    "tokenizer_config.json",
    "chat_template.jinja",
    "model.safetensors.index.json",
    "router_release/config.json",
    "router_release/seed17.safetensors",
    "router_release/seed29.safetensors",
    "router_release/seed43.safetensors",
    "serve.py",
    "xdan_jev_runtime/__init__.py",
    "xdan_jev_runtime/release_runtime.py",
    "xdan_jev_runtime/release_contract.py",
    "xdan_jev_runtime/early_exit.py",
    "xdan_jev_runtime/candidate_projection.py",
    "xdan_jev_runtime/model_family.py",
} | {f"model.safetensors-{index:05d}-of-00004.safetensors" for index in range(1, 5)}


def verify_release(directory):
    directory = Path(directory).resolve()
    manifest = json.loads((directory / "release-manifest.json").read_text())
    if manifest["schema"] not in (SCHEMA_V1, SCHEMA_V2):
        raise ValueError("unsupported release manifest")
    required = set(REQUIRED_RELEASE_FILES)
    if manifest["schema"] == SCHEMA_V2:
        required -= {head_path(SCHEMA_V1, 16, seed) for seed in (17, 29, 43)}
        required |= {
            head_path(SCHEMA_V2, depth, seed)
            for depth in ROUTE_DEPTHS
            for seed in (17, 29, 43)
        }
    if not required.issubset(manifest.get("files", {})):
        raise ValueError("release manifest missing required execution assets")
    if manifest["schema"] == SCHEMA_V2:
        config = json.loads((directory / "router_release/config.json").read_text())
        assets = config.get("verified_base_files")
        if (
            config.get("schema") != SCHEMA_V2
            or not isinstance(assets, dict)
            or not assets
        ):
            raise ValueError("missing verified base assets")
        if any(
            manifest["files"].get(name) != digest for name, digest in assets.items()
        ):
            raise ValueError("manifest missing or mismatched base assets")
    config = json.loads((directory / "router_release/config.json").read_text())
    candidate = config.get("candidate_execution")
    if candidate is not None:
        from .candidate_bundle import validate_bundle_spec

        needed = validate_bundle_spec(candidate)
        if not needed.issubset(manifest["files"]):
            raise ValueError("candidate assets missing from manifest")
        if manifest["files"][candidate["weights"]] != candidate["weights_sha256"]:
            raise ValueError("candidate weights manifest mismatch")
        for name, expected in candidate["source_hashes"].items():
            if manifest["files"].get("xdan_jev_runtime/" + name) != expected:
                raise ValueError("candidate source manifest mismatch")
    for relative, expected in manifest["files"].items():
        path = (directory / relative).resolve()
        if (
            not path.is_relative_to(directory)
            or not path.is_file()
            or file_hash(path) != expected
        ):
            raise ValueError(f"release file hash mismatch: {relative}")
    return manifest


class SemanticJevModel:
    """Own exactly one frozen backbone and one selected FP32 route readout."""

    def __init__(self, base, tokenizer, head, config, variant):
        import torch
        from .early_exit import QwenEarlyExit

        self.base = base.eval()
        self.tokenizer = tokenizer
        self.head = head.float().eval() if head is not None else None
        self.heads = {16: self.head} if self.head is not None else {}
        self.directory = None
        self.config = config
        self.variant = variant
        self.native = QwenEarlyExit(self.base)
        self.device = next(base.parameters()).device
        if self.head is not None:
            self.head.to(self.device)
        for parameter in list(self.base.parameters()) + (
            list(self.head.parameters()) if self.head is not None else []
        ):
            parameter.requires_grad_(False)
        if self.native.full_depth != 32:
            raise ValueError("release requires full d32 backbone")
        if any(
            parameter.dtype != torch.float32
            for parameter in (self.head.parameters() if self.head is not None else [])
        ):
            raise ValueError("route parameters must stay FP32")

    @classmethod
    def from_pretrained(cls, directory, device="cuda", variant="seed17", verify=True):
        import torch
        import transformers
        from transformers import AutoTokenizer, Qwen3_5ForConditionalGeneration

        directory = Path(directory).resolve()
        if transformers.__version__ != "5.16.1":
            raise ValueError(
                "this audited early-exit runtime requires transformers==5.16.1"
            )
        if verify:
            verify_release(directory)
        config = json.loads((directory / "router_release/config.json").read_text())
        if (
            config["schema"] not in (SCHEMA_V1, SCHEMA_V2)
            or config["base_repo"] != BASE_REPO
            or config["base_revision"] != BASE_REVISION
            or config["classes"] != list(CLASSES)
            or config["default_variant"] != "seed17"
            or variant not in {"seed17", "seed29", "seed43"}
        ):
            raise ValueError("unsupported router release identity or variant")
        expected_depths = [16] if config["schema"] == SCHEMA_V1 else list(ROUTE_DEPTHS)
        if config.get("route_depth", 16) != 16 or config.get("full_depth") != 32:
            raise ValueError("invalid backbone/default depth contract")
        if config["schema"] == SCHEMA_V2 and (
            config.get("route_depths") != expected_depths
            or config.get("effort_depths") != EFFORT_DEPTHS
            or config.get("default_effort") != "max"
        ):
            raise ValueError("invalid v2 route control configuration")
        base = Qwen3_5ForConditionalGeneration.from_pretrained(
            str(directory),
            torch_dtype=torch.bfloat16,
            attn_implementation="sdpa",
            local_files_only=True,
        )
        base.to(device)
        tokenizer = AutoTokenizer.from_pretrained(str(directory), local_files_only=True)
        instance = cls(base, tokenizer, None, config, variant)
        instance.directory = directory
        # v1 retains its public .head; v2 heads load only on actual auto use.
        if config["schema"] == SCHEMA_V1:
            instance.head = instance._head_for(16)
        if config.get("candidate_execution") is not None:
            from .research_candidate_backend import ResearchCandidateBackend

            instance.candidate_backend = ResearchCandidateBackend.load_bundle(
                directory,
                config["candidate_execution"],
                instance.device,
                config["base_revision"],
            )
        return instance

    def _head_for(self, depth):
        import torch
        from safetensors import safe_open
        from safetensors.torch import load_file

        if depth in self.heads:
            return self.heads[depth]
        directory, variant = self.directory, self.variant
        path = directory / head_path(self.config["schema"], depth, int(variant[4:]))
        if self.config["schema"] == SCHEMA_V2:
            with safe_open(str(path), framework="pt", device="cpu") as handle:
                tags = handle.metadata() or {}
            if any(
                tags.get(key) != value
                for key, value in {
                    "schema": SCHEMA_V2,
                    "depth": str(depth),
                    "seed": variant[4:],
                    "dtype": "float32",
                }.items()
            ):
                raise ValueError("router depth/seed metadata mismatch")
        states = load_file(
            str(directory / head_path(self.config["schema"], depth, int(variant[4:]))),
            device="cpu",
        )
        expected_shapes = {
            "mean": (4098,),
            "scale": (4098,),
            "linear.weight": (4, 4098),
            "linear.bias": (4,),
        }
        if set(states) != set(expected_shapes) or any(
            tuple(states[k].shape) != shape or states[k].dtype != torch.float32
            for k, shape in expected_shapes.items()
        ):
            raise ValueError("invalid FP32 head tensor contract")
        if (
            any(not torch.isfinite(value).all() for value in states.values())
            or not (states["scale"] > 0).all()
        ):
            raise ValueError("invalid normalization/tensor values")

        class Head(torch.nn.Module):
            def __init__(self):
                super().__init__()
                self.register_buffer("mean", states["mean"])
                self.register_buffer("scale", states["scale"])
                self.linear = torch.nn.Linear(4098, 4)

            def forward(self, features):
                return self.linear((features - self.mean) / self.scale)

        head = Head()
        head.load_state_dict(states, strict=True)
        head.float().eval().to(self.device)
        for parameter in head.parameters():
            parameter.requires_grad_(False)
        self.heads[depth] = head
        return head

    def _sync(self):
        import torch

        if self.device.type == "cuda":
            torch.cuda.synchronize(self.device)

    def enable_research_candidate_backend(self, checkpoint, *, source_hashes):
        """Opt in only after caller verifies a separate research artifact manifest."""
        from .research_candidate_backend import ResearchCandidateBackend

        self.candidate_backend = ResearchCandidateBackend.load(
            checkpoint, source_hashes, self.device, self.config["base_revision"]
        )
        return dict(self.candidate_backend.identity)

    def infer(
        self, body, mode="auto", effort=None, max_new_tokens=128, route_depth=None
    ):
        """Return plain JSON-compatible results; no HTTP or header controls routing."""
        import torch

        if mode not in {"auto", "jev", "llm"}:
            raise ValueError("mode must be auto, jev or llm")
        resolved_effort, depth = resolve_route_controls(
            self.config["schema"], effort, route_depth
        )
        if type(max_new_tokens) is not int or not 1 <= max_new_tokens <= 2048:
            raise ValueError("max_new_tokens must be an integer in1..2048")
        original = clean_input(body)
        prompt = self.tokenizer.apply_chat_template(
            model_messages(original),
            tokenize=False,
            add_generation_prompt=True,
            enable_thinking=False,
        )
        ids = self.tokenizer(
            prompt, add_special_tokens=False, truncation=False
        ).input_ids
        if not ids or len(ids) > 8192:
            raise ValueError(
                "input exceeds8192 tokens or is empty; truncation forbidden"
            )
        for name in (
            "image_token_id",
            "video_token_id",
            "vision_start_token_id",
            "vision_end_token_id",
        ):
            special = getattr(self.base.config, name, None)
            if special is not None and special in ids:
                raise ValueError(
                    "multimodal placeholders unsupported in text-only release"
                )
        original_metadata = metadata(original)
        input_ids = torch.tensor([ids], dtype=torch.long, device=self.device)
        backend = getattr(self, "candidate_backend", None)
        values, compiler_error, candidate_ids = None, None, None
        if backend is None and mode != "llm":
            values, compiler_error = literal_candidates(original)
        if values is not None:
            candidate_ids, compiler_error = candidate_tokens(
                values, self.tokenizer, prompt, ids
            )
        if mode == "jev" and compiler_error:
            raise ValueError("forced JEV unsupported: " + compiler_error)
        self._sync()
        started = time.perf_counter()
        probabilities, semantic_class, state = None, None, None
        route_seconds = 0.0
        head_load_seconds = 0.0
        with torch.inference_mode():
            if mode == "auto":
                load_started = time.perf_counter()
                head = self._head_for(depth)
                self._sync()
                head_load_seconds = time.perf_counter() - load_started
                route_started = time.perf_counter()
                state = self.native.advance(self.native.begin(input_ids), depth)
                hidden = self.native.backbone.norm(state.hidden[:, -1]).float()
                features = torch.cat(
                    (
                        hidden,
                        torch.tensor(
                            [original_metadata], device=self.device, dtype=torch.float32
                        ),
                    ),
                    dim=-1,
                )
                probabilities = head(features).softmax(-1)[0].cpu().tolist()
                semantic_class = CLASSES[max(range(4), key=probabilities.__getitem__)]
                self._sync()
                route_seconds = time.perf_counter() - route_started
            selected = None
            backend_executed = False
            recovery_seconds = continuation_seconds = ranking_seconds = 0.0
            route, reason = choose_route(
                probabilities or [],
                mode,
                backend is not None or candidate_ids is not None,
                original_metadata,
            )
            if backend is not None and route == "jev":
                from .research_candidate_backend import CandidateContractError

                stage = "recover"
                try:
                    t0 = time.perf_counter()
                    contract = backend.recover(original, self.tokenizer, ids)
                    values = contract["values"]
                    self._sync()
                    recovery_seconds = time.perf_counter() - t0
                    stage = "continue"
                    t0 = time.perf_counter()
                    if state is None:
                        state = self.native.begin(input_ids)
                    state = self.native.advance(state, self.native.full_depth)
                    full_hidden = self.native.backbone.norm(state.hidden)
                    self._sync()
                    continuation_seconds = time.perf_counter() - t0
                    stage = "rank"
                    t0 = time.perf_counter()
                    selected = backend.score(full_hidden, contract)
                    self._sync()
                    ranking_seconds = time.perf_counter() - t0
                    backend_executed = True
                    del full_hidden
                except CandidateContractError as error:
                    if stage != "recover":
                        raise
                    recovery_seconds = time.perf_counter() - t0
                    # Data/contract failures only: do not swallow CUDA/resource errors.
                    compiler_error = str(error)
                    if mode == "jev":
                        raise ValueError(
                            "forced JEV unsupported: " + compiler_error
                        ) from None
                    route, reason = "llm", compiler_error
                    state = None
                    if "full_hidden" in locals():
                        del full_hidden
            result = {
                "selected_route": route,
                "mode": mode,
                "variant": self.variant,
                "override": mode != "auto",
                "semantic_class": semantic_class,
                "class_probabilities": dict(zip(CLASSES, probabilities))
                if probabilities is not None
                else None,
                "decision_reason": reason,
                "fallback_reason": (compiler_error or reason)
                if mode == "auto" and route == "llm"
                else None,
                "compiler_reason": compiler_error,
                "original_metadata": original_metadata,
                "requested_effort": effort,
                "requested_route_depth": route_depth,
                "resolved_effort": resolved_effort,
                "resolved_route_depth": depth,
                "route_controls_active": mode == "auto",
                "router_head_id": f"d{depth}-{self.variant}"
                if mode == "auto"
                else None,
                "effective_route_depth": depth if mode == "auto" else None,
                "execution": {
                    "backbone_instances": 1,
                    "route_seconds": route_seconds,
                    "head_lookup_load_seconds": head_load_seconds,
                    "input_tokens": len(ids),
                    "head_dtype": "float32",
                    "prefix_recomputed": mode == "auto" and route == "llm",
                    "generation_cache_reused_from_router": False,
                    "jev_adapter_loaded": backend is not None,
                    "candidate_probabilities_calibrated": False,
                },
            }
            if backend is not None:
                result["candidate_backend"] = dict(backend.identity)
                result["execution"].update(
                    adapter_executed=backend_executed,
                    contract_recovery_seconds=recovery_seconds,
                    continuation_seconds=continuation_seconds,
                    candidate_head_seconds=ranking_seconds,
                )
            if route == "llm":
                del state
                generated = self.base.generate(
                    input_ids, max_new_tokens=max_new_tokens, do_sample=False
                )
                output_ids = generated[0, len(ids) :].cpu().tolist()
                result.update(
                    answer=self.tokenizer.decode(output_ids, skip_special_tokens=True),
                    generated_token_ids=output_ids,
                    finish_reason="length"
                    if len(output_ids) >= max_new_tokens
                    else "stop",
                )
            elif backend is not None:
                winner = max(range(len(values)), key=selected.__getitem__)
                result.update(
                    answer=values[winner],
                    candidate_probabilities=dict(zip(values, selected)),
                    finish_reason="stop",
                )
                result["execution"].update(
                    decision_depth=32,
                    jev_prefix_reused=mode == "auto",
                    projection="native_candidate_ranker_fp32",
                )
            else:
                if state is None:
                    state = self.native.begin(input_ids)
                state = self.native.advance(state, self.native.full_depth)
                # Full native LM head preserves original matmul semantics; no untrained JEV adapter.
                logits = self.base.get_output_embeddings()(
                    self.native.backbone.norm(state.hidden[:, -1])
                )
                selected = logits[0, candidate_ids].float().softmax(-1).cpu().tolist()
                winner = max(range(len(values)), key=selected.__getitem__)
                result.update(
                    answer=values[winner],
                    candidate_probabilities=dict(zip(values, selected)),
                    candidate_token_ids=candidate_ids,
                    finish_reason="stop",
                )
                result["execution"].update(
                    decision_depth=32,
                    jev_prefix_reused=mode == "auto",
                    projection="full_native_lm_head",
                )
        self._sync()
        result["execution"]["total_seconds"] = time.perf_counter() - started
        return result
