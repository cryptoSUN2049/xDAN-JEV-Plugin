"""Versioned standalone candidate assets; quality remains independently gated."""

import re
from .research_candidate_backend import HEAD_SHA, BASE_REVISION, SOURCE_FILES

BUNDLE_SCHEMA = "xdan-native-candidate-bundle-v1"
FIELDS = {
    "schema",
    "backend",
    "weights",
    "weights_sha256",
    "source_checkpoint_sha256",
    "base_revision",
    "representation",
    "source_hashes",
    "quality_approved",
}


def validate_bundle_spec(spec):
    if not isinstance(spec, dict) or set(spec) != FIELDS:
        raise ValueError("candidate_bundle_fields")
    expected = {
        "schema": BUNDLE_SCHEMA,
        "backend": "native_span_ranker_research",
        "weights": "candidate_release/head.safetensors",
        "source_checkpoint_sha256": HEAD_SHA,
        "base_revision": BASE_REVISION,
        "representation": "json_string_literal_with_comma",
    }
    if (
        any(spec.get(k) != v for k, v in expected.items())
        or spec["quality_approved"] is not False
    ):
        raise ValueError("candidate_bundle_identity")
    hashes = spec["source_hashes"]
    if not isinstance(hashes, dict) or set(hashes) != set(SOURCE_FILES):
        raise ValueError("candidate_bundle_sources")
    if any(
        not isinstance(v, str) or not re.fullmatch("[0-9a-f]{64}", v)
        for v in [spec["weights_sha256"], *hashes.values()]
    ):
        raise ValueError("candidate_bundle_hash_format")
    return {spec["weights"], *("xdan_jev_runtime/" + n for n in SOURCE_FILES)}
