"""Map reviewed message character spans to exact chat-template token spans.

The marker render is diagnostic only. It never supplies model input or token IDs.
"""

import hashlib
import re
import secrets
from collections.abc import Mapping


_ROLES = {"system", "user", "assistant"}
_SPECIAL_PATTERN = re.compile(r"<\|[^|>]+\|>")
_TEMPLATE_OPTIONS = {
    "add_generation_prompt": True,
    "enable_thinking": False,
}


def _field(encoded, name):
    return (
        encoded.get(name)
        if isinstance(encoded, Mapping)
        else getattr(encoded, name, None)
    )


def _validate_inputs(tokenizer, messages, candidates):
    if not isinstance(messages, list) or not messages:
        raise ValueError("nonempty text-only messages required")
    special_tokens = getattr(tokenizer, "all_special_tokens", ()) or ()
    for message in messages:
        if (
            not isinstance(message, dict)
            or set(message) != {"role", "content"}
            or message["role"] not in _ROLES
            or not isinstance(message["content"], str)
        ):
            raise ValueError("text-only role/content messages required")
        content = message["content"]
        if _SPECIAL_PATTERN.search(content) or any(
            isinstance(token, str) and token and token in content
            for token in special_tokens
        ):
            raise ValueError("embedded special token in message content")
    if not isinstance(candidates, list) or not 2 <= len(candidates) <= 16:
        raise ValueError("2..16 candidates required")
    values = set()
    for candidate in candidates:
        required = {"message_index", "start", "end", "value"}
        if (
            not isinstance(candidate, dict)
            or not required <= set(candidate)
            or set(candidate) - required - {"source_text"}
        ):
            raise ValueError(
                "candidate requires message_index/start/end/value, optional source_text"
            )
        index, start, end, value = (
            candidate["message_index"],
            candidate["start"],
            candidate["end"],
            candidate["value"],
        )
        source_text = candidate.get("source_text", value)
        if (
            type(index) is not int
            or not 0 <= index < len(messages)
            or type(start) is not int
            or type(end) is not int
            or not isinstance(value, str)
            or not value.strip()
            or not isinstance(source_text, str)
            or not source_text.strip()
            or not 0 <= start < end <= len(messages[index]["content"])
            or messages[index]["content"][start:end] != source_text
        ):
            raise ValueError("invalid candidate source span, source_text or value")
        if value in values:
            raise ValueError("candidate values must be distinct; duplicate value")
        values.add(value)


def _message_positions(tokenizer, messages, prompt):
    # Unique delimiters are wrapped around complete content, not candidate text.
    # This lets explicit message offsets disambiguate repeated candidate strings.
    for _ in range(3):
        nonce = secrets.token_hex(16)
        markers = [
            (
                f"\ue000JEV_CAND_{nonce}_{i}_BEGIN\ue001",
                f"\ue000JEV_CAND_{nonce}_{i}_END\ue001",
            )
            for i in range(len(messages))
        ]
        if all(
            marker not in prompt
            and all(marker not in message["content"] for message in messages)
            for pair in markers
            for marker in pair
        ):
            break
    else:
        raise ValueError("cannot create collision-free diagnostic markers")
    diagnostic_messages = [
        {"role": message["role"], "content": start + message["content"] + end}
        for message, (start, end) in zip(messages, markers)
    ]
    diagnostic = tokenizer.apply_chat_template(
        diagnostic_messages, tokenize=False, **_TEMPLATE_OPTIONS
    )
    if not isinstance(diagnostic, str):
        raise ValueError("diagnostic template render must return text")
    events = []
    for index, (begin, end) in enumerate(markers):
        if diagnostic.count(begin) != 1 or diagnostic.count(end) != 1:
            raise ValueError(
                "diagnostic marker missing or repeated after template render"
            )
        events.extend(
            [
                (diagnostic.index(begin), begin, index, "begin"),
                (diagnostic.index(end), end, index, "end"),
            ]
        )
    events.sort(key=lambda event: event[0])
    positions = [[None, None] for _ in messages]
    chunks = []
    cursor = 0
    original_position = 0
    for location, marker, index, kind in events:
        if location < cursor:
            raise ValueError("overlapping diagnostic markers")
        chunk = diagnostic[cursor:location]
        chunks.append(chunk)
        original_position += len(chunk)
        positions[index][0 if kind == "begin" else 1] = original_position
        cursor = location + len(marker)
    chunks.append(diagnostic[cursor:])
    if "".join(chunks) != prompt:
        raise ValueError("diagnostic template render changed original prompt")
    for index, message in enumerate(messages):
        start, end = positions[index]
        if start is None or end is None or prompt[start:end] != message["content"]:
            raise ValueError("diagnostic message content boundary mismatch")
    return positions


def _token_envelope(prompt, offsets, start, end):
    overlap = [
        index
        for index, (left, right) in enumerate(offsets)
        if left < end and right > start
    ]
    if not overlap:
        raise ValueError("candidate has no offset-mapped token coverage")
    first, last = overlap[0], overlap[-1] + 1
    if overlap != list(range(first, last)):
        raise ValueError(
            "candidate token envelope is not contiguous or contains no-offset token"
        )
    envelope = offsets[first:last]
    if any(left == right for left, right in envelope):
        raise ValueError("no-offset token within candidate envelope")
    char_start = min(left for left, _ in envelope)
    char_end = max(right for _, right in envelope)
    if (not prompt[char_start:start].isspace() and char_start < start) or (
        not prompt[end:char_end].isspace() and char_end > end
    ):
        raise ValueError("candidate token envelope crosses nonwhitespace boundary")
    # A repeated Unicode offset is fine; a hole inside the candidate is not.
    covered_until = start
    for left, right in sorted(envelope):
        if left > covered_until and covered_until < end:
            raise ValueError("offset mapping does not cover candidate")
        covered_until = max(covered_until, right)
    if covered_until < end:
        raise ValueError("offset mapping does not cover candidate")
    return first, last, char_start, char_end


def map_candidate_spans(tokenizer, messages, candidates):
    """Return exact original prompt, IDs and reviewed candidate token envelopes.

    Candidate positions are Python Unicode character offsets in message content.
    Returned prompt and token spans are half-open. Raises ValueError if the
    tokenizer/template cannot prove a faithful mapping.
    """
    _validate_inputs(tokenizer, messages, candidates)
    template = getattr(tokenizer, "chat_template", None)
    if not isinstance(template, str) or not template:
        raise ValueError("chat_template text required for template_sha256")
    prompt = tokenizer.apply_chat_template(
        messages, tokenize=False, **_TEMPLATE_OPTIONS
    )
    if not isinstance(prompt, str):
        raise ValueError("chat template render must return text")
    positions = _message_positions(tokenizer, messages, prompt)
    encoded = tokenizer(
        prompt, add_special_tokens=False, return_offsets_mapping=True, truncation=False
    )
    ids = _field(encoded, "input_ids")
    offsets = _field(encoded, "offset_mapping")
    template_result = tokenizer.apply_chat_template(
        messages, tokenize=True, **_TEMPLATE_OPTIONS
    )
    template_ids = (
        template_result
        if isinstance(template_result, list)
        else _field(template_result, "input_ids")
    )
    if (
        not isinstance(ids, list)
        or not ids
        or not all(type(token_id) is int for token_id in ids)
        or not isinstance(template_ids, list)
        or template_ids != ids
    ):
        raise ValueError("token ids differ from tokenized chat template")
    if not isinstance(offsets, list) or len(offsets) != len(ids):
        raise ValueError("offset mapping length differs from token ids")
    for offset in offsets:
        if (
            not isinstance(offset, (tuple, list))
            or len(offset) != 2
            or any(type(position) is not int for position in offset)
            or not 0 <= offset[0] <= offset[1] <= len(prompt)
        ):
            raise ValueError("invalid offset mapping")
    mapped = []
    for candidate in candidates:
        content_start = positions[candidate["message_index"]][0]
        start = content_start + candidate["start"]
        end = content_start + candidate["end"]
        source_text = candidate.get("source_text", candidate["value"])
        if prompt[start:end] != source_text:
            raise ValueError("candidate source_text differs from original prompt")
        token_start, token_end, char_start, char_end = _token_envelope(
            prompt, offsets, start, end
        )
        mapped.append(
            {
                **candidate,
                "source_text": source_text,
                "value_is_exact_source_text": candidate["value"] == source_text,
                "prompt_start": start,
                "prompt_end": end,
                "token_start": token_start,
                "token_end": token_end,
                "token_char_start": char_start,
                "token_char_end": char_end,
            }
        )
    return {
        "prompt": prompt,
        "input_ids": list(ids),
        "candidates": mapped,
        "template_sha256": hashlib.sha256(template.encode("utf-8")).hexdigest(),
    }
