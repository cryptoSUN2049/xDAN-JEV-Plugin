"""Explicit opt-in legacy-panel native ranker; no general natural recovery claim."""

import hashlib
from pathlib import Path
import re

HEAD_SHA = "8dcc2847b6265eff9e5423dffef1e1491b7d850c991edcafe6c445f10ee2278c"
BASE_REVISION = "c202236235762e1c871ad0ccb60c8ee5ba337b9a"
SOURCE_FILES = (
    "candidate_bundle.py",
    "research_candidate_backend.py",
    "native_candidate_ranker.py",
    "panel_candidate_spans.py",
    "candidate_token_mapping.py",
    "release_runtime.py",
    "release_contract.py",
)


def verify_sources(expected):
    if not isinstance(expected, dict) or set(expected) != set(SOURCE_FILES):
        raise ValueError("candidate_source_manifest_required")
    root = Path(__file__).parent
    for name, value in expected.items():
        if (
            not isinstance(value, str)
            or hashlib.sha256((root / name).read_bytes()).hexdigest() != value
        ):
            raise ValueError("candidate_source_hash_mismatch")
    return dict(expected)


class CandidateContractError(ValueError):
    """Recognized unsupported input contract; safe to fall back in auto mode."""


class ResearchCandidateBackend:
    """Loaded via pinned artifact/source identities; never modifies base weights."""

    @classmethod
    def load(cls, checkpoint, source_hashes, device, base_revision):
        import torch
        from .native_candidate_ranker import NativeCandidateRanker

        hashes = verify_sources(source_hashes)
        if (
            base_revision != BASE_REVISION
            or hashlib.sha256(Path(checkpoint).read_bytes()).hexdigest() != HEAD_SHA
        ):
            raise ValueError("candidate_checkpoint_identity")
        data = torch.load(checkpoint, map_location="cpu", weights_only=True)
        config = data.get("config", {})
        if (
            data.get("schema_version") != "candidate-answer-head-v1"
            or config.get("base_revision") != BASE_REVISION
            or config.get("hidden_size") != 4096
            or config.get("projection_size") != 128
        ):
            raise ValueError("candidate_checkpoint_schema")
        instance = cls()
        instance.head = NativeCandidateRanker()
        instance.head.load_state_dict(data["state_dict"], strict=True)
        if not all(torch.isfinite(p).all().item() for p in instance.head.parameters()):
            raise ValueError("candidate_checkpoint_nonfinite")
        instance.head.to(device).eval().requires_grad_(False)
        instance.identity = {
            "backend": "native_span_ranker_research",
            "checkpoint_sha256": HEAD_SHA,
            "representation": "json_string_literal_with_comma",
            "recovery_scope": "legacy_prompt_v2_only",
            "source_hashes": hashes,
            "natural_recovery_supported": False,
        }
        return instance

    @classmethod
    def load_bundle(cls, directory, spec, device, base_revision):
        import torch
        from safetensors.torch import load_file
        from .candidate_bundle import validate_bundle_spec
        from .native_candidate_ranker import NativeCandidateRanker

        validate_bundle_spec(spec)
        verify_sources(spec["source_hashes"])
        if base_revision != BASE_REVISION:
            raise ValueError("candidate_bundle_base_revision")
        root = Path(directory).resolve()
        path = (root / spec["weights"]).resolve()
        if not path.is_relative_to(root) or not path.is_file():
            raise ValueError("candidate_bundle_weight_path")
        if hashlib.sha256(path.read_bytes()).hexdigest() != spec["weights_sha256"]:
            raise ValueError("candidate_bundle_weight_hash")
        states = load_file(str(path), device="cpu")
        if any(
            v.dtype != torch.float32 or not torch.isfinite(v).all().item()
            for v in states.values()
        ):
            raise ValueError("candidate_bundle_tensor_contract")
        instance = cls()
        instance.head = NativeCandidateRanker()
        instance.head.load_state_dict(states, strict=True)
        instance.head.to(device).eval().requires_grad_(False)
        instance.identity = {
            "backend": spec["backend"],
            "checkpoint_sha256": HEAD_SHA,
            "bundle_weights_sha256": spec["weights_sha256"],
            "representation": spec["representation"],
            "recovery_scope": "legacy_prompt_v2_only",
            "natural_recovery_supported": False,
            "quality_approved": False,
            "source_hashes": dict(spec["source_hashes"]),
        }
        return instance

    def recover(self, original, tokenizer, original_ids):
        from .panel_candidate_spans import locate_panel_candidate_spans
        from .candidate_token_mapping import map_candidate_spans

        if (
            not isinstance(original, dict)
            or set(original) != {"messages"}
            or not isinstance(original["messages"], list)
            or len(original["messages"]) != 1
            or not isinstance(original["messages"][0], dict)
            or not isinstance(original["messages"][0].get("content"), str)
        ):
            raise CandidateContractError("candidate_unsupported_input_scope")
        content = original["messages"][0]["content"]
        match = re.search(
            r"\nReturn only the selected letter: ([A-P](?:, [A-P])+)\.\nAnswer:\Z",
            content,
        )
        if match is None:
            raise CandidateContractError("candidate_unsupported_input_scope")
        values = match.group(1).split(", ")
        try:
            candidates = locate_panel_candidate_spans(
                original["messages"],
                values,
                representation="json_string_literal_with_comma",
            )
        except ValueError as error:
            known = {
                "single_user_panel_prompt_required",
                "invalid_predicted_candidates",
                "panel_prefix_required",
                "unique_canonical_panel_contract_required",
                "predicted_candidate_set_incomplete_or_conflicting",
            }
            if str(error) not in known:
                raise
            raise CandidateContractError("candidate_locator_" + str(error)) from error
        try:
            mapped = map_candidate_spans(tokenizer, original["messages"], candidates)
        except ValueError as error:
            known = {
                "embedded special token in message content": "special_token",
                "candidate token envelope crosses nonwhitespace boundary": "boundary_spill",
                "candidate has no offset-mapped token coverage": "missing_coverage",
                "offset mapping does not cover candidate": "incomplete_coverage",
            }
            if str(error) not in known:
                raise
            raise CandidateContractError(
                "candidate_mapping_" + known[str(error)]
            ) from error
        if mapped["input_ids"] != original_ids:
            raise CandidateContractError("candidate_prompt_identity")
        spans = [(c["token_start"], c["token_end"]) for c in mapped["candidates"]]
        if len(spans) != len(set(spans)) or any(
            a < d and c < b for i, (a, b) in enumerate(spans) for c, d in spans[i + 1 :]
        ):
            raise CandidateContractError("candidate_overlapping_spans")
        return {
            "values": values,
            "token_spans": spans,
            "input_tokens": len(original_ids),
        }

    def score(self, hidden, contract):
        import torch

        spans = torch.tensor([contract["token_spans"]], device=hidden.device)
        attention = torch.ones(hidden.shape[:2], dtype=torch.bool, device=hidden.device)
        logits = self.head(
            hidden,
            spans,
            torch.ones(spans.shape[:2], dtype=torch.bool, device=hidden.device),
            torch.tensor([hidden.shape[1] - 1], device=hidden.device),
            attention,
        )[0]
        if not torch.isfinite(logits).all().item():
            raise ValueError("candidate_nonfinite_logits")
        return logits.softmax(-1).cpu().tolist()
