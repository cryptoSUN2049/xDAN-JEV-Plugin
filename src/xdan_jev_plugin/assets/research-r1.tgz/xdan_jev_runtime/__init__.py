"""Frozen 9B + semantic head custom research loader."""
from .release_runtime import SemanticJevModel
