"""Input-only locator for the legacy prompt.v2 panel, not natural understanding.

Output spans cover raw JSON string interiors (including escape characters),
not decoded description text. No gold or source-record argument is accepted.
"""

import json
import re


def _pairs(items):
    result = {}
    for key, value in items:
        if key in result:
            raise ValueError("duplicate_json_key")
        result[key] = value
    return result


def _dump(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True)


def locate_panel_candidate_spans(
    messages, predicted_values, *, representation="json_literal_interior"
):
    """Return mapper-compatible spans in predicted order; reject partial sets."""
    if representation not in (
        "json_literal_interior",
        "json_string_literal_with_comma",
    ):
        raise ValueError("invalid_representation")
    if (
        not isinstance(messages, list)
        or len(messages) != 1
        or not isinstance(messages[0], dict)
        or set(messages[0]) != {"role", "content"}
        or messages[0]["role"] != "user"
        or not isinstance(messages[0]["content"], str)
    ):
        raise ValueError("single_user_panel_prompt_required")
    if (
        not isinstance(predicted_values, list)
        or not 2 <= len(predicted_values) <= 16
        or any(not isinstance(v, str) or not v.strip() for v in predicted_values)
        or len(set(predicted_values)) != len(predicted_values)
    ):
        raise ValueError("invalid_predicted_candidates")
    content = messages[0]["content"]
    if not content.startswith("Shared state:\n"):
        raise ValueError("panel_prefix_required")
    matches = []
    decoder = json.JSONDecoder(object_pairs_hook=_pairs)
    for match in re.finditer(r"\n\n(?=\{)", content):
        start = match.end()
        try:
            task, end = decoder.raw_decode(content[start:])
        except (ValueError, TypeError):
            continue
        if not isinstance(task, dict) or set(task) != {
            "criteria",
            "instructions",
            "primitive",
        }:
            continue
        criteria = task["criteria"]
        if (
            task["primitive"] not in ("choice", "noul", "score_level")
            or not isinstance(task["instructions"], str)
            or not task["instructions"].strip()
            or not isinstance(criteria, list)
            or not 2 <= len(criteria) <= 16
            or any(
                not isinstance(c, dict)
                or set(c) != {"description", "label"}
                or not isinstance(c["description"], str)
                or not c["description"].strip()
                or not isinstance(c["label"], str)
                for c in criteria
            )
        ):
            continue
        labels = [c["label"] for c in criteria]
        if labels != list("ABCDEFGHIJKLMNOP"[: len(criteria)]):
            continue
        tail = "\nReturn only the selected letter: " + ", ".join(labels) + ".\nAnswer:"
        if content[start + end :] != tail or content[start : start + end] != _dump(
            task
        ):
            continue
        if not content[len("Shared state:\n") : match.start()].strip():
            continue
        matches.append((task, start))
    if len(matches) != 1:
        raise ValueError("unique_canonical_panel_contract_required")
    task, start = matches[0]
    criteria = task["criteria"]
    if set(predicted_values) != {c["label"] for c in criteria}:
        raise ValueError("predicted_candidate_set_incomplete_or_conflicting")
    # Build canonical offsets, never search for the first repeated description.
    cursor = start + len('{"criteria": [')
    spans = {}
    for item in criteria:
        encoded = _dump(item["description"])
        begin = cursor + len('{"description": ') + 1
        end = begin + len(encoded) - 2
        source = encoded[1:-1]
        if representation == "json_string_literal_with_comma":
            begin -= 1
            end += 2
            source = encoded + ","
        if content[begin:end] != source:
            raise ValueError("canonical_span_identity_failed")
        spans[item["label"]] = {
            "message_index": 0,
            "start": begin,
            "end": end,
            "source_text": source,
            "value": item["label"],
        }
        cursor += len(_dump(item)) + 2  # comma-space between criteria objects
    return [spans[value] for value in predicted_values]
