DENSE_TYPES = {"qwen3_5", "qwen3_5_text"}
MOE_TYPES = {"qwen3_5_moe", "qwen3_5_moe_text"}
CONDITIONAL_TYPES = {"qwen3_5", "qwen3_5_moe"}
