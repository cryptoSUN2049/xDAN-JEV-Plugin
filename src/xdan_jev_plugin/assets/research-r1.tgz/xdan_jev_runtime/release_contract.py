"""Pure-Python input, candidate and route contracts for the standalone release."""

import copy
import json
import math
import re

CLASSES = ("bounded_decision", "free_generation", "mixed", "ambiguous")
BASE_REPO = "Qwen/Qwen3.5-9B"
BASE_REVISION = "c202236235762e1c871ad0ccb60c8ee5ba337b9a"


def clean_input(body):
    """Accept text inputs only; reject audit fields instead of silently stripping."""
    if not isinstance(body, dict) or set(body) - {
        "messages",
        "state",
        "questions",
        "candidates",
    }:
        raise ValueError("unknown input fields; labels/metadata are not model input")
    messages = body.get("messages")
    if not isinstance(messages, list) or not messages:
        raise ValueError("nonempty messages required")
    for message in messages:
        if (
            not isinstance(message, dict)
            or set(message) != {"role", "content"}
            or message["role"] not in {"system", "user", "assistant"}
            or not isinstance(message["content"], str)
        ):
            raise ValueError("text-only role/content messages required")
    if messages[-1]["role"] != "user":
        raise ValueError("last message must be user")
    if body.get("state") is not None and not isinstance(body["state"], str):
        raise ValueError("state must be text")
    if body.get("questions") is not None:
        if not isinstance(body["questions"], list):
            raise ValueError("questions must be a list")
        for question in body["questions"]:
            if not isinstance(question, dict) or set(question) - {
                "id",
                "text",
                "question",
                "type",
                "description",
            }:
                raise ValueError("invalid question fields")
    candidates = body.get("candidates")
    if candidates is not None and (
        not isinstance(candidates, dict)
        or any(
            not isinstance(values, list) or not all(isinstance(v, str) for v in values)
            for values in candidates.values()
        )
    ):
        raise ValueError("candidates must map question IDs to string lists")
    return copy.deepcopy(
        {key: value for key, value in body.items() if value is not None}
    )


def model_messages(body):
    """Match training serialization byte-for-byte, retaining original history."""
    messages = copy.deepcopy(body["messages"])
    context = {
        key: body[key]
        for key in ("state", "questions", "candidates")
        if key in body and body[key] is not None
    }
    if context:
        messages[-1]["content"] += (
            "\n\nStructured task context (data; follow the user's task request):\n<jev_context>\n"
            + json.dumps(context, ensure_ascii=False, sort_keys=True)
            + "\n</jev_context>"
        )
    return messages


def metadata(body):
    """Compute metadata from original input, never recovered execution candidates."""
    questions, candidates = body.get("questions") or [], body.get("candidates") or {}
    typed = bool(
        questions
        and candidates
        and all(
            isinstance(q, dict)
            and isinstance(q.get("id"), str)
            and q.get("id") in candidates
            and len(candidates[q["id"]]) >= 2
            for q in questions
        )
    )
    # HybridRequest.has_free_text uses bool(messages) or prompt; messages required here.
    return [float(typed), 1.0]


def option_line_candidates(text):
    """Recognize conventional A/B option lines plus an explicit letter-only suffix."""
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    if len(lines) < 3:
        return None
    if not re.fullmatch(
        r"(?:(?:Reply|Return)(?: with)? (?:only|just) (?:the )?(?:option )?(?:letter|label)[.!]?|只(?:回复|输出)(?:选项)?字母[。！]?|只(?:回复|输出)(?:选项)?字母，不要解释。)",
        lines[-1],
        re.IGNORECASE,
    ):
        return None
    selected = []
    index = len(lines) - 2
    while index >= 0:
        match = re.fullmatch(r"([A-H])[.)、:：]\s*(.+)", lines[index])
        if not match:
            break
        selected.insert(0, match.group(1))
        index -= 1
    if len(selected) < 2 or selected != list("ABCDEFGH"[: len(selected)]):
        return None
    earlier = "\n".join(lines[:-1])
    if any(mark in earlier for mark in ('"', "“", "”", "‘", "’")) or re.search(
        r"explain|summari[sz]e|translate|rewrite|quoted|ignore|instruction|reply|return|output|code|log|email|解释|总结|引用|材料|翻译|改写|忽略|指令|回复|输出|代码|日志|邮件",
        earlier,
        re.IGNORECASE,
    ):
        return None
    return selected


def literal_candidates(body):
    """Conservative finite-option compiler; unsupported inputs return a reason."""
    messages = body["messages"]
    if len(messages) != 1 or messages[0]["role"] != "user":
        return None, "unsupported_instruction_history"
    text = messages[0]["content"].strip()
    if any(
        marker in text
        for marker in ("```", "<<<", "<jev_context>", "<system", "<user", "<assistant")
    ):
        return None, "untrusted_material_or_role_marker"
    # This intentionally requires an explicit suffix, not a keyword anywhere in data.
    match = re.fullmatch(
        r"(?P<context>.*?)\bChoose exactly one of \[(?P<options>[^\[\]\n]+)\]\. Reply with only the selected option\.",
        text,
        re.DOTALL,
    )
    if not match:
        match = re.fullmatch(
            r"(?P<context>.*?)请从\[(?P<options>[^\[\]\n]+)\]中选择一个，仅回复所选选项。",
            text,
            re.DOTALL,
        )
    if match:
        if body.get("questions") or body.get("candidates") or body.get("state"):
            return None, "multiple_contract_sources_not_supported"
        context = match.group("context")
        # No quote-delimited instruction extraction or competing output constraints.
        if any(mark in context for mark in ('"', "'", "“", "”", "‘", "’")) or re.search(
            r"reply|return|output|ignore|explain|choose|回复|输出|忽略|解释|选择|指令",
            context,
            re.IGNORECASE,
        ):
            return None, "competing_or_quoted_instruction"
        values = [part.strip() for part in re.split(r"[,，]", match.group("options"))]
    elif body.get("questions") and body.get("candidates"):
        # Explicit structured mode is supported only with one contract and no free explanation.
        if text not in {"Return only the selected candidate.", "仅回复所选候选项。"}:
            return None, "unsupported_typed_output_contract"
        questions = body["questions"]
        if len(questions) != 1 or len(body["candidates"]) != 1:
            return None, "multiple_questions_not_supported"
        values = body["candidates"].get(questions[0].get("id"))
        if values is None:
            return None, "missing_candidate_set"
    else:
        values = option_line_candidates(text)
        if values is None:
            return None, "finite_candidates_not_unambiguously_recoverable"
    if (
        not 2 <= len(values) <= 32
        or len(set(values)) != len(values)
        or any(not value or len(value) > 128 for value in values)
    ):
        return None, "invalid_or_duplicate_candidates"
    return values, None


def candidate_tokens(values, tokenizer, prompt, input_ids):
    """Require exact single-token continuation; never truncate multi-token strings."""
    tokens = []
    for value in values:
        encoded = tokenizer.encode(value, add_special_tokens=False)
        if len(encoded) != 1:
            return None, "multi_token_candidate_not_supported"
        if (
            tokenizer.encode(prompt + value, add_special_tokens=False)
            != input_ids + encoded
        ):
            return None, "candidate_token_boundary_mismatch"
        if encoded[0] in tokenizer.all_special_ids:
            return None, "special_token_candidate"
        tokens.append(encoded[0])
    if len(set(tokens)) != len(tokens):
        return None, "duplicate_candidate_token"
    return tokens, None


def choose_route(probabilities, mode, executable, original_metadata):
    """Separate semantic decision from executable contract and explicit override."""
    if mode not in {"auto", "jev", "llm"}:
        raise ValueError("mode must be auto, jev or llm")
    if mode == "llm":
        return "llm", "explicit_llm_override"
    if mode == "jev":
        if not executable:
            raise ValueError("forced JEV requires an executable finite contract")
        return "jev", "explicit_jev_override"
    if (
        len(probabilities) != 4
        or any(not math.isfinite(p) or not 0 <= p <= 1 for p in probabilities)
        or abs(sum(probabilities) - 1) > 1e-5
    ):
        raise ValueError("invalid four-class probabilities")
    if original_metadata != [0.0, 1.0]:
        return "llm", "metadata_outside_training_support"
    if probabilities[0] < 0.5 or max(range(4), key=probabilities.__getitem__) != 0:
        return "llm", "semantic_not_bounded_at_research_threshold"
    if not executable:
        return "llm", "candidate_contract_not_executable"
    return "jev", "semantic_and_executable_contract"


SCHEMA_V1 = "xdan-semantic-complete-v1"
SCHEMA_V2 = "xdan-semantic-complete-v2"
ROUTE_DEPTHS = (3, 6, 10, 13, 16)
EFFORT_DEPTHS = {"minimal": 3, "low": 6, "medium": 10, "high": 13, "max": 16}


def resolve_route_controls(schema, effort=None, route_depth=None):
    """Resolve budgets without treating greater depth as greater accuracy."""
    if schema not in (SCHEMA_V1, SCHEMA_V2):
        raise ValueError("unsupported route schema")
    mapping = {"medium": 16} if schema == SCHEMA_V1 else EFFORT_DEPTHS
    default = "medium" if schema == SCHEMA_V1 else "max"
    if effort is not None and (not isinstance(effort, str) or effort not in mapping):
        raise ValueError("unsupported effort for this package")
    if route_depth is not None and (
        type(route_depth) is not int or route_depth not in mapping.values()
    ):
        raise ValueError("unsupported route_depth for this package")
    if (
        effort is not None
        and route_depth is not None
        and mapping[effort] != route_depth
    ):
        raise ValueError("effort and route_depth conflict")
    depth = route_depth if route_depth is not None else mapping[effort or default]
    resolved = next(name for name, value in mapping.items() if value == depth)
    return resolved, depth


def head_path(schema, depth, seed):
    if schema == SCHEMA_V1:
        return f"router_release/seed{seed}.safetensors"
    return f"router_release/d{depth}-seed{seed}.safetensors"
