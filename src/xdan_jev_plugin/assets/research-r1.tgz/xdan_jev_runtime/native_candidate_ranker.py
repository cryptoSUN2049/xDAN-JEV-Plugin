"""Small candidate ranker over verified spans in frozen full-depth hidden states.

The caller owns token-span mapping and output strings. This module only scores
provided spans; it never loads or updates the base model.
"""

import torch
from torch import Tensor, nn


_INTEGER_DTYPES = (torch.uint8, torch.int8, torch.int16, torch.int32, torch.int64)


class NativeCandidateRanker(nn.Module):
    """Score each candidate by a projected query and mean-pooled token span."""

    def __init__(self, hidden_size: int = 4096, projection_size: int = 128):
        super().__init__()
        if type(hidden_size) is not int or hidden_size < 1:
            raise ValueError("hidden_size must be a positive integer")
        if type(projection_size) is not int or projection_size < 1:
            raise ValueError("projection_size must be a positive integer")
        self.hidden_size = hidden_size
        self.query_proj = nn.Linear(
            hidden_size, projection_size, bias=False, dtype=torch.float32
        )
        self.candidate_proj = nn.Linear(
            hidden_size, projection_size, bias=False, dtype=torch.float32
        )

    def forward(
        self,
        hidden: Tensor,
        candidate_spans: Tensor,
        candidate_mask: Tensor,
        query_positions: Tensor,
        attention_mask: Tensor,
    ) -> Tensor:
        """Return FP32 [B,K] logits; masked candidates receive negative infinity.

        Spans are half-open token offsets. Valid spans must end at or before
        the query token, or include it, and may not read padding. Inactive
        candidate slots are ignored, so callers may use empty placeholders.
        """
        tensors = (
            hidden,
            candidate_spans,
            candidate_mask,
            query_positions,
            attention_mask,
        )
        if any(not isinstance(value, Tensor) for value in tensors):
            raise ValueError("all ranker inputs must be tensors")
        if hidden.ndim != 3 or hidden.shape[0] < 1 or hidden.shape[1] < 1:
            raise ValueError("hidden must have shape [B,T,H] with nonempty B,T")
        batch, length, width = hidden.shape
        if width != self.hidden_size or not torch.is_floating_point(hidden):
            raise ValueError("hidden width or floating dtype is invalid")
        if (
            candidate_spans.ndim != 3
            or candidate_spans.shape[0] != batch
            or candidate_spans.shape[2] != 2
        ):
            raise ValueError("candidate_spans must have shape [B,K,2]")
        count = candidate_spans.shape[1]
        if candidate_spans.dtype not in _INTEGER_DTYPES:
            raise ValueError("candidate_spans must contain integer token offsets")
        if candidate_mask.shape != (batch, count) or candidate_mask.dtype != torch.bool:
            raise ValueError("candidate_mask must be bool [B,K]")
        if (
            query_positions.shape != (batch,)
            or query_positions.dtype not in _INTEGER_DTYPES
        ):
            raise ValueError("query_positions must be integer [B]")
        if (
            attention_mask.shape != (batch, length)
            or attention_mask.dtype != torch.bool
        ):
            raise ValueError("attention_mask must be bool [B,T]")
        if any(value.device != hidden.device for value in tensors[1:]) or any(
            parameter.device != hidden.device for parameter in self.parameters()
        ):
            raise ValueError("inputs and ranker parameters must share one device")
        if any(parameter.dtype != torch.float32 for parameter in self.parameters()):
            raise ValueError("ranker projections must remain FP32")
        if count < 2 or (candidate_mask.sum(dim=1) < 2).any():
            raise ValueError("each batch row requires at least two valid candidates")

        frozen = hidden.detach()
        used = torch.zeros((batch, length), dtype=torch.bool, device=hidden.device)
        pooled = torch.zeros(
            (batch, count, width), dtype=torch.float32, device=hidden.device
        )
        for row in range(batch):
            query = int(query_positions[row])
            if query < 0 or query >= length or not bool(attention_mask[row, query]):
                raise ValueError("query position is out of bounds or padding")
            used[row, query] = True
            seen = set()
            for col in range(count):
                if not bool(candidate_mask[row, col]):
                    continue
                start, end = map(int, candidate_spans[row, col])
                if start < 0 or end > length or start >= end or end > query + 1:
                    raise ValueError(
                        "valid candidate span is empty, out of bounds, or after query"
                    )
                if (start, end) in seen:
                    raise ValueError("duplicate valid candidate span")
                seen.add((start, end))
                if not bool(attention_mask[row, start:end].all()):
                    raise ValueError("valid candidate span contains padding")
                used[row, start:end] = True
                pooled[row, col] = frozen[row, start:end].float().mean(dim=0)
        if not bool(torch.isfinite(frozen[used]).all()):
            raise ValueError("read hidden states must be finite")

        indices = torch.arange(batch, device=hidden.device)
        query_states = frozen[indices, query_positions.long()].float()
        with torch.autocast(device_type=hidden.device.type, enabled=False):
            query_vectors = self.query_proj(query_states)
            candidate_vectors = self.candidate_proj(pooled)
            logits = (query_vectors[:, None, :] * candidate_vectors).sum(dim=-1)
        return logits.masked_fill(~candidate_mask, float("-inf"))
