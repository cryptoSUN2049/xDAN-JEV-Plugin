"""Single-request GPU research API for the complete local xDAN model package."""

import argparse
import json
import sys
import time
import uuid
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

MAX_BODY_BYTES = 2 * 1024 * 1024
INPUT_FIELDS = {"messages", "state", "questions", "candidates"}
REQUEST_FIELDS = INPUT_FIELDS | {
    "model",
    "mode",
    "effort",
    "route_depth",
    "max_tokens",
    "temperature",
    "stream",
}


def parse_request(body, model_name):
    if not isinstance(body, dict) or set(body) - REQUEST_FIELDS:
        raise ValueError("unknown request fields")
    if body.get("model", model_name) != model_name:
        raise ValueError("unknown model")
    if body.get("stream", False) is not False:
        raise ValueError("streaming is not supported by this research server")
    if body.get("temperature", 0) != 0:
        raise ValueError("only greedy temperature=0 is supported")
    max_tokens = body.get("max_tokens", 128)
    if type(max_tokens) is not int or not 1 <= max_tokens <= 1024:
        raise ValueError("max_tokens must be an integer between 1 and 1024")
    mode, effort = body.get("mode", "auto"), body.get("effort")
    if mode not in {"auto", "jev", "llm"}:
        raise ValueError("mode must be auto, jev or llm")
    if "messages" not in body:
        raise ValueError("messages required")
    controls = {"mode": mode, "max_new_tokens": max_tokens}
    if "effort" in body:
        if not isinstance(effort, str):
            raise ValueError("effort must be a string")
        controls["effort"] = effort
    if "route_depth" in body:
        if type(body["route_depth"]) is not int:
            raise ValueError("route_depth must be an integer")
        controls["route_depth"] = body["route_depth"]
    return (
        {key: body[key] for key in INPUT_FIELDS if key in body},
        controls,
    )


def make_handler(runtime, model_name):
    class Handler(BaseHTTPRequestHandler):
        def reply(self, status, value):
            encoded = json.dumps(value, ensure_ascii=False, allow_nan=False).encode()
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(encoded)))
            self.end_headers()
            self.wfile.write(encoded)

        def do_GET(self):
            if self.path == "/health":
                self.reply(200, {"status": "ready", "model": model_name})
            elif self.path == "/v1/models":
                self.reply(
                    200,
                    {"object": "list", "data": [{"id": model_name, "object": "model"}]},
                )
            else:
                self.reply(404, {"error": {"message": "not found"}})

        def do_POST(self):
            if self.path != "/v1/chat/completions":
                self.reply(404, {"error": {"message": "not found"}})
                return
            try:
                size = int(self.headers.get("Content-Length", "0"))
                if not 0 < size <= MAX_BODY_BYTES:
                    raise ValueError("body must have a valid Content-Length <= 2 MiB")
                body = json.loads(self.rfile.read(size))
                model_input, kwargs = parse_request(body, model_name)
                started = time.perf_counter()
                result = runtime.infer(model_input, **kwargs)
                elapsed = time.perf_counter() - started
                content = result["answer"]
                if not isinstance(content, str):
                    raise RuntimeError("runtime answer must be text")
                self.reply(
                    200,
                    {
                        "id": "chatcmpl-" + uuid.uuid4().hex,
                        "object": "chat.completion",
                        "created": int(time.time()),
                        "model": model_name,
                        "choices": [
                            {
                                "index": 0,
                                "message": {"role": "assistant", "content": content},
                                "finish_reason": result.get("finish_reason", "stop"),
                            }
                        ],
                        "xdan": {**result, "server_wall_seconds": elapsed},
                    },
                )
            except (ValueError, TypeError, UnicodeError) as exc:
                self.reply(
                    400,
                    {"error": {"type": "invalid_request_error", "message": str(exc)}},
                )
            except Exception:
                # Never send internals, request text or environment to callers.
                self.log_error("model execution failed")
                self.reply(
                    500,
                    {
                        "error": {
                            "type": "internal_error",
                            "message": "model execution failed; inspect server diagnostics",
                        }
                    },
                )

    return Handler


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model-dir", required=True)
    parser.add_argument("--model-name", default="xdan-jev-9b-v3")
    parser.add_argument("--variant", default="seed17")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=18181)
    args = parser.parse_args()
    root = Path(args.model_dir).resolve()
    sys.path.insert(0, str(root))
    from xdan_jev_runtime import SemanticJevModel

    runtime = SemanticJevModel.from_pretrained(
        root, device="cuda", variant=args.variant
    )
    server = HTTPServer((args.host, args.port), make_handler(runtime, args.model_name))
    print(
        json.dumps(
            {
                "event": "ready",
                "host": args.host,
                "port": args.port,
                "model": args.model_name,
                "variant": args.variant,
            }
        ),
        flush=True,
    )
    server.serve_forever()


if __name__ == "__main__":
    main()
