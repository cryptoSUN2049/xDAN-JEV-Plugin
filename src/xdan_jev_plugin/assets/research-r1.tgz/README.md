# Qwen 9B native candidate integration — research validation build

One frozen Qwen3.5-9B backbone, five route depths and a 1,048,576-parameter candidate head.
`SemanticJevModel.from_pretrained` automatically loads the bundled safetensors head.
`serve.py` uses that same loader; `auto`, `jev`, `llm`, effort and route_depth are retained.

**Quality gate failed:** the current trained candidate head obtains 182/500 on the exposed
JEV panel; the original LM candidate projection obtains 327/500. Do not promote this build
as an improved production model. 75 panel examples overlap the head selection set.

Recovery currently supports the canonical legacy prompt.v2 format. Unsupported auto inputs
fall back to original LLM generation; forced JEV rejects unsupported input. Natural-language
candidate recovery and native vLLM integration remain incomplete. API compatibility is not
vLLM engine compatibility. The base SFT weights are unchanged.
